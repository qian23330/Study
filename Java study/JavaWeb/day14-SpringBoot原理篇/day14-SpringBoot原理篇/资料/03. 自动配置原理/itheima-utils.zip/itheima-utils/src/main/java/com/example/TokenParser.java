package com.example;

import org.springframework.stereotype.Component;

@Component
public class TokenParser {

    public void parse(){
        System.out.println("TokenParser ... parse ...");
    }

}
